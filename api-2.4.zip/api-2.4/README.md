# CryptoChat API 2.3

The CryptoChat API is the central relay for the CryptoChat platform. Frontends send and receive end-to-end encrypted messages to the API via Socket.IO.